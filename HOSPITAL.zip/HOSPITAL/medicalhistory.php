<?php
      include'include/connection.php';
      include'include/header.php'; 
?>

<body class="index-page">

 
 
        <nav id="navmenu" class="navmenu">
          <ul>
            <li><a href="index.php" >Home<br></a></li>
            
            <li><a href="#departments" class="active">Register</a></li>
            <!-- <li><a href="sundaycalculator.html">Calculator</a></li> -->
          </ul>
          <i class="mobile-nav-toggle d-xl-none bi bi-list"></i>
        </nav>
      </div>

    </div>

  </header>


  <main class="main">

    <!-- Hero Section -->
    <section id="hero" class="hero section light-background">

      <img src="assets/img/hero-bg.jpg" alt="" data-aos="fade-in">

      <div class="container position-relative">


<?php

// register

$aa=$_GET['id'];
$aaa="SELECT *FROM followup where FOLLOW_UP='$aa'";
$ab=mysqli_query($dbcon,$aaa);
$ac=mysqli_fetch_array($ab);

// $ge=$_GET['id'];
//   $g="SELECT *FROM followup where FOLLOW_UP='$ge'";
//   $t=mysqli_query($dbcon,$g);
//   $ac=mysqli_fetch_array($t);






if (isset($_POST['save'])) {
      // code...




    $in=$_POST['fcbsc'];
      $a=$_POST['a'];
      $b=$_POST['b'];
      $c=$_POST['c'];
      $d=$_POST['d'];
      $e=$_POST['e'];
      $F=$_POST['F'];
      $g=$_POST['g'];
      $h=$_POST['h'];
      $i=$_POST['i'];
      $j=$_POST['j'];
      $k=$_POST['k'];
      $l=$_POST['l'];
      $m=$_POST['m'];
      $n=$_POST['n'];
      $o=$_POST['o'];
      $P=$_POST['P'];
      $q=$_POST['q'];
      $r=$_POST['r'];
      $s=$_POST['s'];
      $t=$_POST['t'];
      $u=$_POST['u'];
      $v=$_POST['v'];
      $a1=$_POST['a1'];
      $a2=$_POST['a2'];
      $a3=$_POST['a3'];
      $a4=$_POST['a4'];
      $a5=$_POST['a5'];
      $a6=$_POST['a6'];

  $insert=mysqli_query($dbcon,"INSERT into history(FCBSC2,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,A1,A2,A3,A4,A5,A6)VALUES
('$in','$a','$b','$c','$d','$e','$F','$g','$h','$i','$j','$k','$l','$m','$n','$o','$p','$q','$r','$s','$t','$u','$v','$a1','$a2','$a3','$a4','$a5','$a6')");
  $update=mysqli_query($dbcon,"UPDATE followup SET STATUS_FOLLOWUP='1'");
if ($insert){
  echo "<script>window.alert('Successful Update the student data'); window.location='printfollowup.php';</script>";
}
else{
  echo "<script>window.alert('Hoop!!! something went wrong,contact ur programmer'); 
  window.location='register.php';</script>";
}
}
?>
<!-- FORM -->


<div class="alert alert-success alert-dismissible">
  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
  <strong>Success!</strong>  Welcome&nbsp;<?php echo $ac['FULLNAME'];?>
</div>


<form   class="form-group" method="post">
       <input type="text" class="form-control  btn btn-danger disabled mt-3"  value="<?php echo $ac['FOLLOW_UP'];?>"  name="fcbsc" required>
      <div class="container">
            <!--  -->
            <dic class="card">
                  <div  class="card-body">
                       <!----<label type=""></label> -->
      <h4>Have you ever in your life been diagnosed with, had or do you presently have any of the following? answere:(YES/NO)</h4>
                       <div class="row">
                             <div class="col-sm-4">
                                   <br>
                                   <ol    style="color: black;" type="1">

                                    
                                    <!-- A -->
                                    <li>
                                    <div class="form-check">
<h5> Frequently or fainting spell</h5>
YES &nbsp;&nbsp;<input class="btn btn-block btn-primary"  name="a" type="radio" value="YES" >
NO &nbsp;&nbsp;<input class="btn btn-block btn-primary"  name="a" type="radio" value="NO" >
                                     </div>
                                     </li>
                                     <!-- A -->
                                     <!-- B -->
                                     <li>
                                    <div class="form-check">
<h5> Allergy</h5>
YES &nbsp;&nbsp;<input class="btn btn-block btn-primary"  name="b" type="radio" value="YES" >
NO &nbsp;&nbsp;<input class="btn btn-block btn-primary"  name="b" type="radio" value="NO" >
                                     </div>
                                     </li>
                                     <!-- B -->
                                     <!-- C -->
                                     <li>
                                    <div class="form-check">
<h5> Dizziness or fainting spell</h5>
YES &nbsp;&nbsp;<input class="btn btn-block btn-primary"  name="c" type="radio" value="YES" >
NO &nbsp;&nbsp;<input class="btn btn-block btn-primary"  name="c" type="radio" value="NO" >
                                     </div>
                                     </li>
                                     <!-- C -->
                                     <!-- D -->
                                     <li>
                                    <div class="form-check">
<h5> Eye or  vision trouble except glasses</h5>
YES &nbsp;&nbsp;<input class="btn btn-block btn-primary"  name="d" type="radio" value="YES" >
NO &nbsp;&nbsp;<input class="btn btn-block btn-primary"  name="d" type="radio" value="NO" >
                                     </div>
                                     </li>
                                     <!-- D -->
                                     <!-- E -->
                                     <li>
                                    <div class="form-check">
<h5> Asthma or lung disease</h5>
YES &nbsp;&nbsp;<input class="btn btn-block btn-primary"  name="e" type="radio" value="YES" >
NO &nbsp;&nbsp;<input class="btn btn-block btn-primary"  name="e" type="radio" value="NO" >
                                     </div>
                                     </li>
                                     <!-- E -->
                                     <!-- F -->
                                     <li>
                                    <div class="form-check">
<h5>Heart or vascular trouble</h5>
YES &nbsp;&nbsp;<input class="btn btn-block btn-primary"  name="F" type="radio" value="YES" >
NO &nbsp;&nbsp;<input class="btn btn-block btn-primary"  name="F" type="radio" value="NO" >
                                     </div>
                                     </li>
                                     <!-- F -->
                                     <li>
                                          <!-- G -->
                                    <div class="form-check">
<h5>High or low blood presure</h5>
YES &nbsp;&nbsp;<input class="btn btn-block btn-primary"  name="g" type="radio" value="YES" >
NO &nbsp;&nbsp;<input class="btn btn-block btn-primary"  name="g" type="radio" value="NO" >
                                     </div>
                                     </li>
                                     <!-- G -->
                                     <!-- H-->
                                     <li>
                                    <div class="form-check">
<h5> Stomach, liver or intestinal trouble</h5>
YES &nbsp;&nbsp;<input class="btn btn-block btn-primary"  name="h" type="radio" value="YES" >
NO &nbsp;&nbsp;<input class="btn btn-block btn-primary"  name="h" type="radio" value="NO" >
                                     </div>
                                     </li>
                                     <!-- H -->
                                     <!-- I -->
                                     <li>
                                    <div class="form-check">
<h5> Kidney stone or blood in urine</h5>
YES &nbsp;&nbsp;<input class="btn btn-block btn-primary"  name="i" type="radio" value="YES" >
NO &nbsp;&nbsp;<input class="btn btn-block btn-primary"  name="i" type="radio" value="NO" >
                                     </div>
                                     </li>
                                     <!-- I-->
                                     <!-- j -->
                                      <li>
                                    <div class="form-check">
<h5>Diabetes</h5>
YES &nbsp;&nbsp;<input class="btn btn-block btn-primary"  name="j" type="radio" value="YES" >
NO &nbsp;&nbsp;<input class="btn btn-block btn-primary"   name="j" type="radio" value="NO" >
                                     </div>
                                     </li>
                                     <!-- j -->
                                     <!-- k -->
                                     <li>
                                    <div class="form-check">
<h5>Neurological disorder; Epilepsy, Stoke, Paralysis, Tremors</h5>
YES &nbsp;&nbsp;<input class="btn btn-block btn-primary"  name="k" type="radio" value="YES" >
NO &nbsp;&nbsp;<input class="btn btn-block btn-primary"   name="k" type="radio" value="NO" >
                                     </div>
                                     </li>
                                     <!-- k -->
                                     <!-- l -->
                                     <li>
                                    <div class="form-check">
<h5> Depresson, Anxiety</h5>
YES&nbsp;&nbsp;<input class="btn btn-block btn-primary"  name="l" type="radio" value="YES" >
NO&nbsp;&nbsp;<input class="btn btn-block btn-primary"  name="l" type="radio" value="NO" >
                                     </div>
                                     </li>
                                     <!-- l -->
                                     <!-- m -->
                                     <li>
                                    <div class="form-check">
<h5>Alcohol</h5>
YES &nbsp;&nbsp;<input class="btn btn-block btn-primary"  name="m" type="radio" value="YES" >
NO &nbsp;&nbsp;<input class="btn btn-block btn-primary"  name="m" type="radio" value="NO" >
                                     </div>
                                     </li>
                                     <!-- m -->
                                     <!-- n -->
                                     <li>
                                    <div class="form-check">
<h5> Kidney stone or blood in urine</h5>
YES &nbsp;&nbsp;<input class="btn btn-block btn-primary"  name="n" type="radio" value="YES" >
NO &nbsp;&nbsp;<input class="btn btn-block btn-primary"  name="n" type="radio" value="NO" >
                                     </div>
                                     </li>
                                     <!-- n -->
                              </ol>
                             </div>
                             <div class="col-sm-4">

                              <h3>Section B</h3>
                              <ol>
                              <hr>
                              <li>
                              <h5> Are you now being treated for any condition? </h5>
                              <select  name="o"  style="color: black;" type="1"  class="form-control">
                                    <option>Click</option>
                                    <option value="YES">Yes</option>
                                    <option  value="NO">No</option>
                              </select>
                              <h5  class="mt-3">If so, specify:</h5>
                              <input type="text" name="p"  class="form-control">
                        </li>
                        <li>
                              <h5  class="mt-3"> Have you ever been hospitalized? </h5>
                              <select  name="q"   class="form-control">
                                    <option>Click</option>
                                    <option value="YES">Yes</option>
                                    <option  value="NO">No</option>
                              </select>
                               <h5  class="mt-3">If so, when and why?</h5>
                              <input type="text" name="r"  class="form-control">
                        </li>

                        <li>
                              <h5  class="mt-3"> Have you ever been absent from work for longer than one month  through illness? </h5>
                              <select  name="s"   class="form-control">
                                    <option>Click</option>
                                    <option value="YES">Yes</option>
                                    <option  value="NO">No</option>
                              </select>
                               <h5  class="mt-3">If so, what illness?</h5>
                              <input type="text" name="t"  class="form-control">
                              <h5  class="mt-3">When?</h5>
                              <input type="text" name="u"  class="form-control">
                        </li>
                        <li>
                               <h5  class="mt-3">State additional facts of importance about your health</h5>
                              <textarea name="v" rows="10" cols="30" class="form-control">
                                    any?------------
                              </textarea>
                        </li>
                        </ol>

                             </div>
                             <div class="col-sm-4">
                                   <h1> Section C</h1>
                                   <!-- <select>
                                       <option>Yes</option>

                                       <option>Yes</option>
                                       <option>No</option>
                                   </select> -->
                                <h2  style=""  class="mt-3"><b>Family History<b></h2>

                                <h5  class="mt-3">"Has any relative had"</h5>

                                   <ol>
                                    <li>
                                         <h5  class="mt-3">Heart disease?</h5>
                                        <select  name="a1"   class="form-control">
                                    <option>None</option>
                                    <option value="YES">Yes</option>
                                    <option  value="NO">No</option>
                              </select>
                                    </li>
                                    <li>
                                         <h5  class="mt-3">Diabetes?</h5>
                                        <select  name="a2"   class="form-control">
                                    <option>None</option>
                                    <option value="YES">Yes</option>
                                    <option  value="NO">No</option>
                              </select>
                                    </li>
                                    <li>
                                         <h5  class="mt-3">Asthma?</h5>
                                        <select  name="a3"   class="form-control">
                                    <option>None</option>
                                    <option value="YES">Yes</option>
                                    <option  value="NO">No</option>
                              </select>
                                    </li>
                                    <li>
                                         <h5  class="mt-3">Tuberculosis?</h5>
                                        <select  name="a4"   class="form-control">
                                    <option>Click</option>
                                    <option value="YES">Yes</option>
                                    <option  value="NO">No</option>
                              </select>
                                    </li>
                                    <li>
                                         <h5  class="mt-3">Cancer?</h5>
                                        <select  name="a5"   class="form-control">
                                    <option>None</option>
                                    <option value="YES">Yes</option>
                                    <option  value="NO">No</option>
                              </select>
                                    </li>
                                    <li>
                                         <h5  class="mt-3">Epilepsy?</h5>
                                        <select  name="a6"   class="form-control">
                                    <option>None</option>
                                    <option value="YES">Yes</option>
                                    <option  value="NO">No</option>
                              </select>
                                    </li>

                                   </ol>
                        <input type="submit"  name="save" class="btn btn-primary mt-3 btn-right float-end">

                             </div>
                              

  
                  </div>
            </div>

      </div>






</form>
<!-- end of form -->

  <a href="#" id="scroll-top" class="scroll-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Preloader -->
  <div id="preloader"></div>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/glightbox/js/glightmbox.min.js"></script>
  <script src="assets/vendor/purecounter/purecounter_vanilla.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>

  <!-- Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>