<?php
      include'include/connection.php';
      include'include/header.php'; 
?>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>


<!--  start php -->
<body class="index-page">

 
 
        <nav id="navmenu" class="navmenu">
          <ul>
           <!--  <li><a href="index.php" >Home<br></a></li>
            
            <li><a href="#departments" class="active">Register</a></li>
            <li><a href="checkdata.php" class="">Check data</a></li> -->
            <!-- <li><a href="sundaycalculator.html">Calculator</a></li> -->
          </ul>
          <i class="mobile-nav-toggle d-xl-none bi bi-list"></i>
        </nav>
      </div>

    </div>

  </header>


  <main class="main">

    <!-- Hero Section -->
    <section id="hero" class="hero section light-background">

      <img src="assets/img/hero-bg.jpg" alt="" data-aos="fade-in">

      <div class="container position-relative">

        <div class="row">
        <div class="col-sm-3"></div>
        <div class="col-sm-6">
        <?php 

        $gg=$_GET['id'];
$ab="SELECT *from fcbsc_reg where FCBSC1='$gg'";
$ac=mysqli_query($dbcon,$ab);
$ad=mysqli_fetch_array($ac);

if(isset($_POST['save'])){
$fn=$_POST['fn'];
$date=$_POST['date'];
$month=$_POST['month'];

$address=$_POST['address'];
$contact=$_POST['contact'];
$occ=$_POST['occ'];
$gender=$_POST['gender'];
$today=$_POST['today'];
$update=mysqli_query($dbcon,"UPDATE fcbsc_reg  SET FULLNAME='$fn',DATEOFBIRTH='$date',MONTH='$month',HOUSEADDRESS='$address',PHONENUMBER='$contact',GENDER='$gender',OCCUPATION='$occ' where FCBSC1='$gg'");
if ($update) {
    echo "<script>
      swal({
  title: 'You have successfull updated,$fn',
  text: 'You clicked the button!',
  icon: 'warning',
  buttons:'okay'  
      
}).then(function() {
              window.location = 'checkdata.php';
            });

</script>";

   }
  else
  {
  echo "<script>

 swal({
  title: 'login fail',
  text: 'You clicked the button!',
  icon: 'error',
  button: 'error!'
})
.then(function() {
              window.location = 'register.php';
            });         
      

</script>";
}
}
 ?>
  <form class="form-group"   method="post">
<label for="fullName">Full Name</label>

            <input type="text" class="form-control" value="<?php echo $ad['FULLNAME'];  ?>" name='fn' required>
            <label>Date of Birth</label>
            <input type="month" class="form-control mt-2"  value="<?php echo $ad['DATEOFBIRTH'];  ?>"  name="date" required>
        
            
               <label >Month</label>
            <input type="" class="form-control mt-2" value="<?php echo $ad['MONTH'];?>"name='month' required>

            <label >House Address</label>
            <input type="text" class="form-control  mt-2"  value="<?php echo $ad['HOUSEADDRESS'];?>" required name='address'>
            <label >Phone Number</label>
          <input type="contact" class="form-control  mt-2" value="<?php echo $ad['PHONENUMBER'];?>" required  name='contact'>
          
  <label >Occupation </label>
<input   type="text" name='occ' class="form-control  mt-2" value="<?php echo $ad['OCCUPATION'];?>" required>
            
<label >Gender </label>
<select   value="<?php echo $ad['GENDER'];?>" name='gender' class="form-control mt-3" >
<option value="Male">Male</option>          
<option value="Female">Female</option>          
          </select>
<input type="hidden" class="form-control  mt-2"   value="<?php echo date('y-m-d');?>" name="today">

        <input type="submit"  value="Update patient"  name="save" class="btn btn-primary mt-3 float-right">
            </form>
        </div>
        </div>
        <div class="col-sm-2"></div>
        </div>
          </div>
  <!-- End Why Box -->
  <!-- Scroll Top -->
  <a href="#" id="scroll-top" class="scroll-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Preloader -->
  <div id="preloader"></div>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/purecounter/purecounter_vanilla.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>

  <!-- Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>