<?php

// $host ="localhost";
// $password ="";
// $username ="root";
// $dbname ="students";
// $dbcon=mysqli_connect($host,$password,$username,$dbname);
// if(!$dbcon){
//     echo"not connect";
// }
// else{
//     echo"connected";
// }

$host ="localhost";
$username ="root";
$password ="";
$dbname ="fcbsc";
$dbcon=mysqli_connect($host,$username,$password,$dbname);
// if(!$dbcon){
//     echo"not connected";
// }
// else{
//     echo"connected";
// }








?>