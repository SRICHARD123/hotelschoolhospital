<?php
      include'include/connection.php';
      include'include/header.php';
 
   
?>



<br><br><br><br><br>
<div class="container-fluid mt-5">
<div class="row">
<div class="col-sm-12">
<!--  -->
<div class="card">
<div class="card-body">





<style>

body{
    background-color:white;
    overflow-x:hidden;
}
      @media print {
            body * {
                visibility: hidden;
            }

        .print-container,.print-container *{
            visibility: visible;
        }
        .con {
            visibility:hidden;
        }

      }
  </style>  

<!--  -->

<?php 
// register

$ge=$_GET['id'];
$g="SELECT *FROM history where HISTORY_ID='$ge'";
$t=mysqli_query($dbcon,$g);
$f=mysqli_fetch_array($t);
?>
<!--  -->
<div class="row print-container mt-5">  
<div class="col-sm-2"></div>
<div class="col-sm-6 ">
    <div class="card">
        <div class="card-body">
            <!-- start -->
            <ul style="list-style-type:none;">
            <h4   style="text-align: center; color:gold;">Patient History</h4>
    <
            <hr>
<ul style="list-style-type:none; ">
       <h4> <li>Full Name: <?php echo $f['A'];?></h4>
       
       
       
    </ul>
    <!-- end -->

    
   
  





<!-- end -->

<button   name="print" onclick="window.print();" class="btn btn-success mt-5 float-right con">Click here to print the reciept</button>
    </div>

    </div>
  
</div>
<div class="col-sm-2">

    </div>
</div>
 </div>
</div>










</div>
</div>
<!--  -->



</div>

</div>
</div>
<br><br>
<footer class="">

<p>&copy Richard</p>

</footer>