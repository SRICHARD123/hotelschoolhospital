<?php
      include'include/connection.php';
      include'include/header.php'; 
?>


  <?php


if(!isset($_SESSION['id'])){
  echo"<script>window.alert('you need to login first');window.location='index.php';</script>";
}



?>
   <header  id="header" class="header sticky-top">
  <!-- End Top Bar -->
    <div class="branding d-flex align-items-center">

      <div class="container position-relative d-flex align-items-center justify-content-between">
        <a href="index.php" class="logo d-flex align-items-center me-auto">
          <!-- Uncomment the line below if you also wish to use an image logo -->
          <!-- <img src="assets/img/logo.png" alt=""> -->
          <h1 class="sitename">Admin</h1>
        </a>
        <nav id="navmenu" class="navmenu">
          <ul>
            <li><a href="#hero" class="btn btn-primary text-white">Admin<br></a></li>
            <li><a href="register.php">Register</a></li>
            <!-- <li><a href="medicalhistory.php">medical history</a></li> -->
            <li><a href="#services">Services</a></li>
            <li><a href="logout.php">Logout</a></li>
            <li><a href=" Printfollowup.php">follow-up</a></li>
            </ul>
            <i class="mobile-nav-toggle d-xl-none bi bi-list"></i>
        </nav>
        <a class="cta-btn d-none d-sm-block" href="checkdata.php">check all data</a>
      </div>
    </div>
  </header>
  </header>


  <main >

    <!-- Hero Section -->
    <section  class="light-background">

     
      <div class=" ">

        <div class="row ">
      
        <div class="col-sm-12">

        <h1 class="bg-white text-center text-dark">REPORT ON FREE COMMUNITY BASED SPECIALIST CLINIC PROGRAM (<?php echo date('Y');?>&nbsp;,<?php echo date('F'); ?>)</h1>


<table class="table table-bordered table-condensed table-hover table-white  text-center"  style="font-size:20px;">
       <thead  class="  btn-danger ">
     <tr class=""   style="font-size:16px;">
       <th >sn</th>
       <th>FULL NAME</th>
       <th>DATEOFBIRTH</th>
       <th>AGE</th>
       <th>HOUSEADDRESS</th>
       <th>OCCUPATION</th>
       <th>GENDER</th>
      
        </tr>
   </thead>
     <tr  >
<?php
$count=1;
$sell="SELECT *FROM  fcbsc_reg WHERE DATE(TODAY) = CURDATE()";
$conss=mysqli_query($dbcon,$sell);
while($view_me=mysqli_fetch_array($conss)){
    
?>

      <td><?php echo $count++; ?></td>
       <td><?php echo $view_me['FULLNAME'];?></td>
       <td><?php echo $view_me['DATEOFBIRTH'];?></td>
       <td><?php echo $view_me['AGE'];?></td>
       <td><?php echo $view_me['HOUSEADDRESS'];?></td>
       <td><?php echo $view_me['OCCUPATION'];?></td>
       <td><?php echo $view_me['GENDER'];?></td>
        <td>
         <a href="editroom.php?id=<?php echo $view_me['FCBSC1'];?>"class="btn btn-primary"style="font-size:11px;"><i class="fa fa-pen" aria-hidden="true"></i></a>
       </td>
           <td>
        <?php
          if($view_me['STATUS'] =='3'){?>
           
            <a href="check_out.php?id=<?php echo $view_me['FCBSC1'];?>" class="btn btn-danger btn-sm  disabled " >following </a>

 <!-- pd -->
           <!-- pd -->
           <?php }elseif($view_me['STATUS']=='2'){ ?>
            <a href="followup.php?id=<?php echo $view_me['FCBSC1'];?>" class="btn btn-success disabled btn-sm " >paid </a>
             <?php }elseif($view_me['STATUS']=='0'){ ?>
            <a href="followup.php?id=<?php echo $view_me['FCBSC1'];?>" class="btn btn-success btn-sm ">follow up</a>
  <?php }elseif($view_me['STATUS']=='1'){ ?>
            <a href="followup?id=<?php echo $view_me['FCBSC1'];?>" class="btn btn-success  btn-sm"><p> follow up</p></a>
 
 
 
      <?php }?>
       </td>
           
       <td><a href="Delete.php?id=<?php echo $view_me['FCBSC1'];?>" class="btn btn-danger btn-sm " >Delete </a>
</td>
     
     <!--  -->
       </tr>
       <?php }?>

   </table>
   <button onclick="window.print();" class="btn btn-success mt-5 float-right con">Click here to print the reciept</button>
</div>
<!-- <div class="col-sm-1"></div> -->
</div>
</div> 
 </div>
        </div>
          </div><!-- End Why Box -->
  <!-- Scroll Top -->
  <a href="#" id="scroll-top" class="scroll-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>
  <!-- Preloader -->
  <div id="preloader"></div>
  <!-- Vendor JS Files -->
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/purecounter/purecounter_vanilla.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <!-- Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>