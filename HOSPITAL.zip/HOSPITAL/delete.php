

<?php
      include'include/connection.php';
      include'include/header.php'; 
?>


<?php

$del=$_GET['id'];
// $delete=mysqli_query($dbcon,"DELETE FROM register where id='$del'");
$u=mysqli_query($dbcon,"UPDATE fcbsc_reg SET TRASH_USER='0' where FCBSC1='$del'");
$u1=mysqli_query($dbcon,"UPDATE followup SET DELETE_STATUS='0' where FOLLOW_UP='$del'");

if($u && $u1){

    echo "<script>
      swal({
  title: 'you are about to delete the patient',
  text: 'You clicked the button!',
  icon: 'warning',
  buttons:'okay'  
      
}).then(function() {
              window.location = 'checkdata.php';
            });

</script>";

   }
  else
  {
  echo "<script>

 swal({
  title: 'login fail',
  text: 'You clicked the button!',
  icon: 'error',
  button: 'error!'
})
.then(function() {
              window.location = 'register.php';
            });         
      

</script>";
}


?>

