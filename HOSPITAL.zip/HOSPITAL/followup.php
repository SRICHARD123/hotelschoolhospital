<?php
      include'include/connection.php';
      include'include/header.php'; 
?>
<!--  start php -->
<body class="index-page">

 
        <div class="social-links d-none d-md-flex align-items-center">
          <a href="#" class="twitter"><i class="bi bi-twitter-x"></i></a>
          <a href="#" class="facebook"><i class="bi bi-facebook"></i></a>
          <a href="#" class="instagram"><i class="bi bi-instagram"></i></a>
          <a href="#" class="linkedin"><i class="bi bi-linkedin"></i></a>
        </div>
      </div>
    </div><!-- End Top Bar -->

    <div class="branding d-flex align-items-center">

      <div class="container position-relative d-flex align-items-center justify-content-between">
        <a href="index.php" class="logo d-flex align-items-center me-auto">
          <!-- Uncomment the line below if you also wish to use an image logo -->
          <!-- <img src="assets/img/logo.png" alt=""> -->
          <h1 class="sitename">FCBSC</h1>
        </a>

        <nav id="navmenu" class="navmenu">
          <ul>
            <li><a href="index.php" >Home<br></a></li>
            
            <li><a href="#departments" class="active">Follow up</a></li>
           
      
            <li><a href="sundaycalculator.html">Calculator</a></li>
          </ul>
          <i class="mobile-nav-toggle d-xl-none bi bi-list"></i>
        </nav>

      </div>

    </div>

  </header>
<h4 class="text-center   alert alert-danger">Follow Up Patient  </h4>

  <main class="main">

    <!-- Hero Section -->
    <section id="hero" class="hero section light-background">

      <img src="assets/img/hero-bg.jpg" alt="" data-aos="fade-in">

      <div class="container position-relative">

        <div class="row">
        <div class="col-sm-3"></div>
        <div class="col-sm-6">
        <?php 

$aa=$_GET['id'];
$aaa="SELECT *FROM fcbsc_reg where FCBSC1='$aa'";
$ab=mysqli_query($dbcon,$aaa);
$ac=mysqli_fetch_array($ab);





if(isset($_POST['save'])){
$fn=$_POST['fn'];
$fcbsc=$_POST['fcbsc'];
$followupdate=$_POST['fd'];
$gender=$_POST['gender'];
$purpose=$_POST['purpose'];
$note=$_POST['note'];

$insert=mysqli_query($dbcon,"INSERT into followup
(FULLNAME,FCBSC1,TODAY1,GENDER,PURPOSE,NOTE)VALUES('$fn','$fcbsc','$followupdate','$gender','$purpose','$note')");

$up=mysqli_query($dbcon,"UPDATE fcbsc_reg set STATUS='3' where FCBSC1='$aa'");

if ($insert){
  echo "<script>window.alert('Successful Update the student data'); window.location='printfollowup.php';</script>";
}
else{
  echo "<script>window.alert('Hoop!!! something went wrong,contact ur programmer'); 
  window.location='followup.php';</script>";
}
}
 ?>
  <form class="form-group"   method="post">
<label for="fullName">Full Name</label>
            <input type="text" class="form-control"  value="<?php echo $ac['FULLNAME'];  ?>"  name="fn" required>
            <label for="fullName">UserID</label>
            <input type="text" class="form-control  btn btn-danger disabled mt-3"  value="FCBSC<?php echo $ac['FCBSC1'];?>"  name="fcbsc" required>
            <label for="fullName">Follow update</label>
            <input type="text" class="form-control  btn btn-danger disabled mt-3"  value="<?php echo $ac['TODAY'];?>"  name="fd" required>

<label >Gender </label>
<select class="form-control mt-3" name="gender">
<option value="Male">Male</option>          
<option value="Female">Female</option>          
          </select>
          <label for="fullName">Purpoe</label>

            <textarea name="purpose" class="form-control" rows="10" cols="30">
The cat was playing in the garden.
</textarea>
            <label for="fullName">Note</label>

           <textarea name="note" rows="10" cols="30" class="form-control">
The cat was playing in the garden.
</textarea>


<input type="hidden" class="form-control  mt-2" disabled value="<?php echo date('y-m-d');     ?>"  name="today" required>

        <input type="submit"  name="save" class="btn btn-primary mt-3 float-right">
            </form>
        </div>
        </div>
        <div class="col-sm-2"></div>
        </div>
          </div><!-- End Why Box -->
  <!-- Scroll Top -->
  <a href="#" id="scroll-top" class="scroll-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Preloader -->
  <div id="preloader"></div>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/purecounter/purecounter_vanilla.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>

  <!-- Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>