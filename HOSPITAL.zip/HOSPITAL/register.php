<?php
      include'include/connection.php';
      include'include/header.php'; 
?>
<!--  start php -->
<body class="index-page">

 
 
        <nav id="navmenu" class="navmenu">
          <ul>
            <li><a href="index.php" >Home<br></a></li>
            
            <li><a href="#departments" class="active">Register</a></li>
            <li><a href="checkdata.php" class="">Check data</a></li>
            <!-- <li><a href="sundaycalculator.html">Calculator</a></li> -->
          </ul>
          <i class="mobile-nav-toggle d-xl-none bi bi-list"></i>
        </nav>
      </div>

    </div>

  </header>


  <main class="main">

    <!-- Hero Section -->
    <section id="hero" class="hero section light-background">

      <img src="assets/img/hero-bg.jpg" alt="" data-aos="fade-in">

      <div class="container position-relative">

        <div class="row">
        <div class="col-sm-3"></div>
        <div class="col-sm-6">
        <?php 

if(isset($_POST['save'])){
$fn=$_POST['fn'];
$date=$_POST['date'];
$month=$_POST['month'];
$age=$_POST['age'];
$address=$_POST['address'];
$contact=$_POST['contact'];
$fnk=$_POST['fnk'];
$pnk=$_POST['pnk'];
$occ=$_POST['occ'];
$gender=$_POST['gender'];
$today=$_POST['today'];
$insert=mysqli_query($dbcon,"INSERT into fcbsc_reg(FULLNAME,DATEOFBIRTH,MONTH,AGE,HOUSEADDRESS,PHONENUMBER,FNK,PNK,OCCUPATION,GENDER,TODAY)VALUES
('$fn','$date','$month','$age','$address','$contact','$fnk','$pnk','$occ','$gender','$today')");
if ($insert){
  echo "<script>window.alert('Successful Update the student data'); window.location='checkdata.php';</script>";
}
else{
  echo "<script>window.alert('Hoop!!! something went wrong,contact ur programmer'); 
  window.location='register.php';</script>";
}
}
 ?>
  <form class="form-group"   method="post">
<label for="fullName">Full Name</label>

            <input type="text" class="form-control"  name="fn" required>
            <label >Date of Birth</label>
            <input type="month" class="form-control mt-2"  name="date" required>
               <!-- <label >Month</label> -->
            <input type="hidden" class="form-control mt-2" value="<?php echo date('y/m');?>" name="month" required>
<!-- <label >Age</label> -->
            <input type="hidden" class="form-control mt-2"  value=""  name="age" required>
            <label >House Address</label>
            <input type="text" class="form-control  mt-2"  name="address" required>
            <label >Phone Number</label>
          <input type="contact" class="form-control  mt-2"  name="contact" required>
          <label >Full name Next of Kin </label>
    <input type="text" class="form-control  mt-2"  name="fnk" required>
    <label >Phone Number Next of Kin </label>
  <input type="text" class="form-control  mt-2"  name="pnk" required>
  
  <label >Occupation </label>
<input type="text" class="form-control  mt-2"  name="occ" required>
            
<label >Gender </label>
<select class="form-control mt-3" name="gender">
<option value="Male">Male</option>          
<option value="Female">Female</option>          
          </select>
<input type="hidden" class="form-control  mt-2"   value="<?php echo date('y-m-d');?>" name="today">

        <input type="submit"  name="save" class="btn btn-primary mt-3 float-right">
            </form>
        </div>
        </div>
        <div class="col-sm-2"></div>
        </div>
          </div>
  <!-- End Why Box -->
  <!-- Scroll Top -->
  <a href="#" id="scroll-top" class="scroll-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Preloader -->
  <div id="preloader"></div>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/purecounter/purecounter_vanilla.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>

  <!-- Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>