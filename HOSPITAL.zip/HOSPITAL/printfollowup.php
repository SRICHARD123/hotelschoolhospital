<?php
      include'include/connection.php';
    include'include/header.php'; 
?>

<?php


if(!isset($_SESSION['id'])){
  echo"<script>window.alert('you need to login first');window.location='index.php';</script>";
}
?>


<body class="index-page">

 
 
        <header  id="header" class="header sticky-top">
  <!-- End Top Bar -->
    <div class="branding d-flex align-items-center">

      <div class="container position-relative d-flex align-items-center justify-content-between">
        <a href="index.php" class="logo d-flex align-items-center me-auto">
          <!-- Uncomment the line below if you also wish to use an image logo -->
          <!-- <img src="assets/img/logo.png" alt=""> -->
          <h1 class="sitename">Admin</h1>
        </a>
        <nav id="navmenu" class="navmenu">
          <ul>
            <li><a href="#hero" class="btn btn-primary text-white">Admin<br></a></li>
            <li><a href="register.php">Register</a></li>
            <!-- <li><a href="medicalhistory.php">medical history</a></li> -->
            <li><a href="#services">Services</a></li>
            <li><a href="logout.php">Logout</a></li>
            <li><a href=" Printfollowup.php">follow-up</a></li>
            </ul>
            <i class="mobile-nav-toggle d-xl-none bi bi-list"></i>
        </nav>
        <a class="cta-btn d-none d-sm-block" href="checkdata.php">check all data</a>
      </div>
    </div>
  </header>
  </header>



<!-- this is for login -->
<br><br><br><br><br><br>
<div class="container-fluide">
        <h2 class="text-center mb-4">Hospital Follow-Up Table</h2>     
<div class="input-group mb-3">
    <input class="form-control" id="searchInput" type="text" placeholder="Search for patients (by Name, Email, Phone Number, or Price)">
    <button class="btn btn-primary" onclick="searchPatient()">Search</button>

        </div>
     
          



        <!-- Patient Table -->

        <table class="table table-bordered table-hover">
            <thead class="table-dark">
                <tr>
        <th>sn</th>
        <th>PATIENT_ID</th>
       <th>Full Name</th>
     <th> Follow-Up Date</th>
       <th>Purpose</th>
       <th> Notes</th>
       <th>Create History</th>>
       <th>View History</th>>
      <th>Update History</th>>
      </tr>
            </thead>

            <?php
$count=1;
$sell="SELECT *FROM followup where DELETE_STATUS='1'";
$conss=mysqli_query($dbcon,$sell);
while($f=mysqli_fetch_array($conss)){
    
    
?> 
            <tbody id="patientTable">
            <tr>

<td><?php echo $count++; ?></td>
       <td style="background-color:red; color: white;" ><?php echo $f['FCBSC1'];?></td>
       <td><?php echo $f['FULLNAME'];?></td>
       <td><?php echo $f['TODAY1'];?></td>
       <td><?php echo $f['PURPOSE'];?></td>
       <td><?php echo $f['NOTE'];?></td>
       <td>
      <?php
          if($f['STATUS_FOLLOWUP'] =='0'){?>
           
            <a href="medicalhistory.php?id=<?php echo $f['FOLLOW_UP'];?>" class="btn btn-success btn-sm  "><i class="fa fa-edit" aria-hidden="true"></i></a>

 <!-- pd -->
           <!-- pd -->
           <?php }elseif($f['STATUS_FOLLOWUP']=='1'){ ?>
            <a href="medicalhistory.php?id=<?php echo $f['FOLLOW_UP'];?>"  style="background:red;" class="btn btn-danger disabled btn-sm " ><i class="fa fa-edit" aria-hidden="true"></i></a>
 
      <?php }?>
       </td>

       <td>
 <?php
          if($f['STATUS_FOLLOWUP'] =='0'){?>
           
            <a href="history.php?id=<?php echo $f['FOLLOW_UP'];?>"    class="btn btn-danger btn-sm disabled  "><i class="fa fa-eye" aria-hidden="true"></i></a>

 <!-- pd -->
           <!-- pd -->
           <?php }elseif($f['STATUS_FOLLOWUP']=='1'){ ?>
            <a href="history.php?id=<?php echo $f['FOLLOW_UP'];?>"  style="background: red;" class="btn btn-success  btn-sm " ><i class="fa fa-eye" aria-hidden="true"></i></a>
           
       <?php }?>
       </td>
       <td>
           <a href="updatefollowup.php?id=<?php echo $f['FOLLOW_UP'];?>" class="btn btn-success btn-sm "><i class="fa fa-redo" aria-hidden="true"></i></a>
       </td>
           
             
      </tr>
            </tbody>
                   <?php }?>


        </table>

        </div>
</div>


</div>
</section>
</main>
<!--  -->











        </div>








          
        </div>
      </div>
    
    

<!-- Bootstrap JS Bundle (includes Popper) -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

    <script>
        function searchPatient() {
            let input = document.getElementById("searchInput").value.toLowerCase();
            let tableRows = document.querySelectorAll("#patientTable tr");

            tableRows.forEach(row => {
                let rowData = row.innerText.toLowerCase();
                row.style.display = rowData.includes(input) ? "" : "none";
            });
        }
    </script>






  <div id="preloader"></div>
  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>