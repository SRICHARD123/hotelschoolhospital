<?php
      include'include/connection.php';
      include'include/header.php';
  
   
?>
<!--  -->




<!--  -->
<body class="index-page">

  <header id="header" class="header sticky-top">

  <!-- End Top Bar -->

    <div class="branding d-flex align-items-center">

      <div class="container position-relative d-flex align-items-center justify-content-between">
        <a href="index.php" class="logo d-flex align-items-center me-auto">
          <!-- Uncomment the line below if you also wish to use an image logo -->
          <!-- <img src="assets/img/logo.png" alt=""> -->
          <h1 class="sitename">Admin</h1>
        </a>

        <nav id="navmenu" class="navmenu">
          <ul>
            <li><a href="#hero" class="btn btn-primary text-white">Home<br></a></li>
            <li><a href="register.php">Register</a></li>
            <!-- <li><a href="medicalhistory.php">medical history</a></li> -->
            <li><a href="#services">Services</a></li>
            <li><a href="about.php">Update Report</a></li>
            
            
       
            <li><a href=" Printfollowup.php">follow-up</a></li>
          </ul>
          <i class="mobile-nav-toggle d-xl-none bi bi-list"></i>
        </nav>

        <a class="cta-btn d-none d-sm-block" href="checkdata.php">check all data</a>

      </div>

    </div>

<?php
if(isset($_POST['save'])){
$name=$_POST['name'];
$code=$_POST['code'];
$select=mysqli_query($dbcon,"SELECT *FROM admin1 where NAME='$name' and CODE='$code'");
$fex=mysqli_fetch_array($select);

   if($fex){
    $_SESSION['id']=$fex['ADMIN'];
     echo "<script>
      swal({
    title: '$name',
    text: 'login successful',
    icon: 'success',
    button: 'okay!'
    }).then(function() {
          window.location = 'checkdata.php';
          });
    </script>";
     }
    else
    {
    echo "<script>
    
     swal({
    title: 'you are welcome',
    text: 'fail to login user,
    icon: 'error',
    button: 'error!'
    }).then(function() {
          window.location = 'login.php';
          });         
    </script>";
     
    }
}
?>
  </header>


  <main class="main">

    <!-- Hero Section -->
    <section id="hero" class="hero section light-background">

      <img src="assets/img/hero-bg.jpg" alt="" data-aos="fade-in">

      <div class="container position-relative">

        <div class="welcome position-relative" data-aos="fade-down" data-aos-delay="100"  style="background-color: rgba(94, 7, 40, 0.445);" >
          <h2>FREE COMMUNITY BASED <br>SPECIALIST CLINIC PROGRAM</h2>
        </div><!-- End Welcome -->

        <div class="content row gy-4">
          <div class="col-lg-4 d-flex align-items-stretch">
            <div class="why-box" data-aos="zoom-out" data-aos-delay="200">
              <h3>Why Choose Us</h3>
              
                This program is an essential tool for fostering healthier communities, reducing the strain on emergency care systems, and ensuring that everyone has access to the healthcare they deserve.iqua. Duis aute irure dolor in reprehenderit
                This program is an essential tool for fostering healthier communities, reducing the strain on emergency care systems, and ensuring that everyone has access to the healthcare they deserve.
              
              <form class="form-group"  method="post">
                <input type="text" name="name" class="form-control mt-3" value=""  required> 
              
                <input type="text" name="code" class="form-control mt-3" value="password"> 
                <input type="submit" name="save" class="form-control mt-3  text-white  bg-danger" value="Login"  required  style="background-color:green;"> 
              </form>
              <div class="text-center">
                <a href="printreport.php" class="more-btn"><span>Print today report</span> <i class="bi bi-chevron-right"></i></a>
              </div>
            </div>
          </div><!-- End Why Box -->

          

  <!-- Scroll Top -->
  <a href="#" id="scroll-top" class="scroll-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Preloader -->
  <div id="preloader"></div>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/purecounter/purecounter_vanilla.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>

  <!-- Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>